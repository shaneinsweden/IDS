﻿using System;
using System.Security.Cryptography.X509Certificates;
using TyranIds.Interfaces;

namespace TyranIds
{
	public class Sensor : ISensor
	{
		private readonly INetworkTrafficInformationSource informationSource;
		private readonly IRule rule;

		public Sensor(INetworkTrafficInformationSource infoSource, IRule idsRule)
		{
			informationSource = infoSource;
			rule = idsRule;
		}

		public int UnreadBufferCount => informationSource.BufferCount;

		public bool ProcessNextMessage()
		{
			string message = informationSource.GetNextMessage();

			return rule.Match(message);
		}

		public INetworkTrafficInformationSource InformationSource { get { throw new NotImplementedException(); } set { throw new NotImplementedException(); } }
	}
}