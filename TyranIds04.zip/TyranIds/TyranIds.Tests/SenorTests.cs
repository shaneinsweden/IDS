﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace TyranIds.Tests
{
	[TestClass]
	public class SenorTests
	{
		//Sensors
		//Configure the sensor
		//A sensor receives network information
		//It checks the information against a rule set
		//If there is a match it generates an alert.

		//
		[TestMethod]
		public void CreateSensorWithInformationSource_NormalData_CountsInformationItemsCorrectly()
		{
			//arrange
			var sensor = Substitute.For<ISensor>();
			var informationSource = Substitute.For<INetworkTrafficInformationSource>();
			informationSource.AddNetworkMessage("hello");
			informationSource.AddNetworkMessage("hello");
			informationSource.AddNetworkMessage("hello");
			informationSource.BufferCount.Returns(3);

			//act
			sensor.InformationSource = informationSource;

			//assert
			Assert.AreEqual(3,sensor.InformationSource.BufferCount);
		}
	}

	public interface INetworkTrafficInformationSource
	{
		void AddNetworkMessage(string hello);
		int BufferCount { get; set; }
	}

	public interface ISensor
	{
		INetworkTrafficInformationSource InformationSource { get; set; }
	}
}
