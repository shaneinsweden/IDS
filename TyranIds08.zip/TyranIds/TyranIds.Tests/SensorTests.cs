﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using NSubstitute.Core;
using TyranIds.Interfaces;

namespace TyranIds.Tests
{
	[TestClass]
	public class SensorTests
	{
		//Sensors
		//Configure the sensor
		//A sensor receives network information
		//It checks the information against a rule set
		//If there is a match it generates an alert.

		//
		[TestMethod]
		public void UseSubSensorWithInformationSource_NormalData_CountsInformationItemsCorrectly()
		{
			//arrange
			var sensor = Substitute.For<ISensor>();
			var informationSource = Substitute.For<INetworkTrafficInformationSource>();
			informationSource.AddNetworkMessage("hello");
			informationSource.AddNetworkMessage("hello");
			informationSource.AddNetworkMessage("hello");
			informationSource.BufferCount.Returns(3);

			//act
			sensor.InformationSource = informationSource;

			//assert
			Assert.AreEqual(3,sensor.InformationSource.BufferCount);
		}

		[TestMethod]
		public void CreateSimpleSensorWithInformationSource_NormalData_CountsInformationItemsCorrectly()
		{
			//arrange
			var informationSource = new SimpleInformationSource();
			informationSource.AddNetworkMessage("hello");
			informationSource.AddNetworkMessage("hello");
			informationSource.AddNetworkMessage("hello");
			var sensor = new Sensor(informationSource, null);

			//act
			
			//assert
			Assert.AreEqual(3,sensor.UnreadBufferCount);
		}

		[TestMethod]
		public void CreateSimpleSensorWithInformationSource_NormalData_ProcessMessageCorrectly()
		{
			//arrange
			var informationSource = new SimpleInformationSource();
			informationSource.AddNetworkMessage("hacking attempt");
			informationSource.AddNetworkMessage("hello");
			informationSource.AddNetworkMessage("hello");
			SimpleRule rule = new SimpleRule("hacking attempt");
			var sensor = new Sensor(informationSource, rule);

			//act
			bool result = sensor.ProcessNextMessage();
			
			//assert
			Assert.AreEqual(true,result);
			Assert.AreEqual(2, sensor.UnreadBufferCount);
		}

				[TestMethod]
		public void CreateSimpleSensorWithInformationSource_FtpAdminLoginData_ProcessMessageCorrectly()
		{
			//arrange
			var informationSource = new SimpleInformationSource();
			informationSource.AddNetworkMessage("USER admin");
			informationSource.AddNetworkMessage("hello");
			informationSource.AddNetworkMessage("hello");
			SimpleRule ftpRule = new SimpleRule("USER admin");
			var sensor = new Sensor(informationSource, ftpRule);

			//act
			bool result = sensor.ProcessNextMessage();
			
			//assert
			Assert.AreEqual(true,result);
			Assert.AreEqual(2, sensor.UnreadBufferCount);
		}
	}
}
