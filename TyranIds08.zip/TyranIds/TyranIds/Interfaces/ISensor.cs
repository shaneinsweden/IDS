﻿namespace TyranIds.Interfaces
{
	public interface ISensor
	{
		INetworkTrafficInformationSource InformationSource { get; set; }
	}
}