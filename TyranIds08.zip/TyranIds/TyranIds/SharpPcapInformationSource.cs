using System;
using System.CodeDom;
using PacketDotNet;
using SharpPcap;

namespace TyranIds
{
	public class SharpPcapInformationSource : SimpleInformationSource
	{
		private ICaptureDevice captureDevice;

		public event EventHandler NetworkAlert;

		public SharpPcapInformationSource(TestCaptureDevice device, int i)
		{
			captureDevice = device;
			captureDevice.OnPacketArrival += CaptureDevice_OnPacketArrival;
		}

		private void CaptureDevice_OnPacketArrival(object sender, CaptureEventArgs e)
		{
			AddNetworkMessage(e.Packet.Data.ToString());
			NetworkEventArgs netArgs = ExtractNetworkInformation(e.Packet);

			NetworkAlert(this, netArgs);
		}

		private NetworkEventArgs ExtractNetworkInformation(RawCapture packet)
		{
			EthernetPacket ethernetPacket = PacketDotNet.Packet.ParsePacket(LinkLayers.Ethernet, packet.Data) as EthernetPacket;
			IpPacket ipPacket = ethernetPacket.Extract(typeof(IpPacket)) as IpPacket;
			TcpPacket tcpPacket = ethernetPacket.Extract(typeof(TcpPacket)) as TcpPacket;

			return new NetworkEventArgs(ipPacket.DestinationAddress.ToString(), tcpPacket.DestinationPort.ToString(), ipPacket.SourceAddress.ToString(), tcpPacket.SourcePort.ToString());
		}

		public void StartListening()
		{
			captureDevice.StartCapture();
		}

	}


	public class NetworkEventArgs : EventArgs
	{
		public string  DestinationIpAddress { get; set; }
		public string SourceIpAddress { get; set; }
		public string DestinationPort { get; set; }
		public string SourcePort { get; set; }

		public NetworkEventArgs(string destIpAddress, string destPort, string srcIpAddress, string srcPort)
		{
			DestinationIpAddress = destIpAddress;
			SourceIpAddress = srcIpAddress;
			DestinationPort = destPort;
			SourcePort = srcPort;
		}
	}
}