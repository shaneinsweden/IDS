﻿using System;
using System.Threading.Tasks;
using System.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using NSubstitute.Core;
using PacketDotNet;
using SharpPcap;
using TyranIds.Common;
using TyranIds.Data;

namespace TyranIds.Tests
{
	[TestClass]
	public class SensorTests
	{
		//Sensors
		//Configure the sensor
		//A sensor receives network information
		//It checks the information against a rule set
		//If there is a match it generates an alert.

		//
		[TestMethod]
		public void UseSubSensorWithInformationSource_NormalData_CountsInformationItemsCorrectly()
		{
			//arrange
			var sensor = Substitute.For<ISensor>();
			var informationSource = Substitute.For<IInformationSource>();
			var netEvenTArgs = new NetworkEventArgs(string.Empty, 0, string.Empty, 0, string.Empty, DateTime.Now, Guid.NewGuid());
			informationSource.AddNetworkMessage(netEvenTArgs);
			informationSource.AddNetworkMessage(netEvenTArgs);
			informationSource.AddNetworkMessage(netEvenTArgs);
			informationSource.BufferCount.Returns(3);

			//act
			sensor.InformationSource = informationSource;

			//assert
			Assert.AreEqual(3,sensor.InformationSource.BufferCount);
		}

		[TestMethod]
		public void CreateSimpleSensorWithInformationSource_NormalData_CountsInformationItemsCorrectly()
		{
			//arrange
			var informationSource = new SimpleInformationSource();
			var netEvenTArgs = new NetworkEventArgs(string.Empty, 0, string.Empty, 0, string.Empty, DateTime.Now, Guid.NewGuid());
			informationSource.AddNetworkMessage(netEvenTArgs);
			informationSource.AddNetworkMessage(netEvenTArgs);
			informationSource.AddNetworkMessage(netEvenTArgs);
			var sensor = new Sensor(informationSource, null);

			//act
			
			//assert
			Assert.AreEqual(3,sensor.UnreadBufferCount);
		}

		[TestMethod]
		public void CreateSimpleSensorWithInformationSource_NormalData_ProcessMessageCorrectly()
		{
			//arrange
			var informationSource = new SimpleInformationSource();
			var netEvenTArgs = new NetworkEventArgs(string.Empty, 0, string.Empty, 0, "hacking attempt", DateTime.Now, Guid.NewGuid());
			var netEvenTArgs2 = new NetworkEventArgs(string.Empty, 0, string.Empty, 0, "hello", DateTime.Now, Guid.NewGuid());
			var netEvenTArgs3 = new NetworkEventArgs(string.Empty, 0, string.Empty, 0, "hello", DateTime.Now, Guid.NewGuid());
			informationSource.AddNetworkMessage(netEvenTArgs);
			informationSource.AddNetworkMessage(netEvenTArgs2);
			informationSource.AddNetworkMessage(netEvenTArgs3);
			SimpleRule rule = new SimpleRule("hacking attempt");
			var sensor = new Sensor(informationSource, rule);

			//act
			bool result = sensor.ProcessNextMessage();
			
			//assert
			Assert.AreEqual(true,result);
			Assert.AreEqual(2, sensor.UnreadBufferCount);
		}

		[TestMethod]
		public void CreateSimpleSensorWithInformationSource_FtpAdminLoginData_ProcessMessageCorrectly()
		{
			//arrange
			var informationSource = new SimpleInformationSource();
			var netEvenTArgs = new NetworkEventArgs(string.Empty, 0, string.Empty, 0, "USER admin", DateTime.Now, Guid.NewGuid());
			var netEvenTArgs2 = new NetworkEventArgs(string.Empty, 0, string.Empty, 0, "hello", DateTime.Now, Guid.NewGuid());
			var netEvenTArgs3 = new NetworkEventArgs(string.Empty, 0, string.Empty, 0, "hello", DateTime.Now, Guid.NewGuid());
			informationSource.AddNetworkMessage(netEvenTArgs);
			informationSource.AddNetworkMessage(netEvenTArgs2);
			informationSource.AddNetworkMessage(netEvenTArgs3);
			SimpleRule ftpRule = new SimpleRule("USER admin");
			var sensor = new Sensor(informationSource, ftpRule);

			//act
			bool result = sensor.ProcessNextMessage();
			
			//assert
			Assert.AreEqual(true,result);
			Assert.AreEqual(2, sensor.UnreadBufferCount);
		}

		[TestMethod]
		public async Task CreateHostSweepSensor_HostSweepPackets_HostScanAlertCtreated()
		{
			//arrange
			IDataAgent datagAgent = new EfDataAgent();
			DatabaseReporter reportAgent = new DatabaseReporter(datagAgent);
			RawCapture[] trafficDataForTest = CreateNetworkDataForTest();
			var captureDevice = new TestCaptureDevice(trafficDataForTest);
			SharpPcapInformationSource networkInformationSource = new SharpPcapInformationSource(captureDevice, 2000);
			IRule hostScanRule = new HostScanRule(5);
			Sensor hostScanSensor = new Sensor(networkInformationSource, hostScanRule, reportAgent);

			using (TransactionScope transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
			{		
				//act
				hostScanSensor.Start();
				await TestPause();
				int numberofHostScanAlerts = datagAgent.CountAlerts();

				//assert
				Assert.AreEqual(1, numberofHostScanAlerts);
			}
		}

		private RawCapture[] CreateNetworkDataForTest()
		{
			RawCapture capturedPacket = new RawCapture(LinkLayers.Ethernet, new PosixTimeval(),  new byte[]
			{
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x56, 
				0xc0, 0x00, 0x08, 0x08, 0x00, 0x45, 0x00, 0x00, 0x1c, 
				0xe2, 0x85, 0x00, 0x00, 0x3b, 0x01, 0xbe, 0x07, 0xc0, 
				0xa8, 0x2f, 0x01, 0xc0, 0xa8, 0x2f, 0x02, 0x08, 0x00, 
				0xc5, 0x7f, 0x32, 0x80, 0x00, 0x00, 
			});

			RawCapture capturedPacket2 = new RawCapture(LinkLayers.Ethernet, new PosixTimeval(),  new byte[]
			{
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x56, 
				0xc0, 0x00, 0x08, 0x08, 0x00, 0x45, 0x00, 0x00, 0x1c, 
				0x6c, 0xf4, 0x00, 0x00, 0x32, 0x01, 0x3c, 0x96, 0xc0, 
				0xa8, 0x2f, 0x01, 0xc0, 0xa8, 0x2f, 0x05, 0x08, 0x00, 
				0xab, 0xe2, 0x4c, 0x1d, 0x00, 0x00, 
			});

			RawCapture capturedPacket3 = new RawCapture(LinkLayers.Ethernet, new PosixTimeval(),  new byte[]
			{
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x56, 
				0xc0, 0x00, 0x08, 0x08, 0x00, 0x45, 0x00, 0x00, 0x1c, 
				0x1c, 0x32, 0x00, 0x00, 0x3a, 0x01, 0x85, 0x57, 0xc0, 
				0xa8, 0x2f, 0x01, 0xc0, 0xa8, 0x2f, 0x06, 0x08, 0x00, 
				0x30, 0x4e, 0xc7, 0xb1, 0x00, 0x00, 
			});

			RawCapture capturedPacket4 = new RawCapture(LinkLayers.Ethernet, new PosixTimeval(),  new byte[]
			{
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x56, 
				0xc0, 0x00, 0x08, 0x08, 0x00, 0x45, 0x00, 0x00, 0x1c, 
				0x5a, 0x71, 0x00, 0x00, 0x37, 0x01, 0x4a, 0x17, 0xc0, 
				0xa8, 0x2f, 0x01, 0xc0, 0xa8, 0x2f, 0x07, 0x08, 0x00, 
				0xa9, 0x56, 0x4e, 0xa9, 0x00, 0x00, 
			});

			RawCapture capturedPacket5 = new RawCapture(LinkLayers.Ethernet, new PosixTimeval(),  new byte[]
			{
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x56, 
				0xc0, 0x00, 0x08, 0x08, 0x00, 0x45, 0x00, 0x00, 0x1c, 
				0xc7, 0x27, 0x00, 0x00, 0x35, 0x01, 0xdf, 0x5f, 0xc0, 
				0xa8, 0x2f, 0x01, 0xc0, 0xa8, 0x2f, 0x08, 0x08, 0x00, 
				0xb1, 0xdf, 0x46, 0x20, 0x00, 0x00, 
			});

			return new RawCapture[5] {capturedPacket, capturedPacket2, capturedPacket3, capturedPacket4, capturedPacket5};
		}


		private async Task TestPause()
		{
			await Task.Delay(20000);
		}
	}
}
