﻿namespace TyranIds.Common
{
	public interface ISensor
	{
		IInformationSource InformationSource { get; set; }
	}
}