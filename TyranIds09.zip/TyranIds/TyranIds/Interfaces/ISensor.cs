﻿namespace TyranIds.Interfaces
{
	public interface ISensor
	{
		IInformationSource InformationSource { get; set; }
	}
}