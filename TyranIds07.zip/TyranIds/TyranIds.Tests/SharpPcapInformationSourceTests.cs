﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using NSubstitute.Core;
using SharpPcap;
using SharpPcap.LibPcap;
using SharpPcap.WinPcap;
using TyranIds.Interfaces;

namespace TyranIds.Tests
{
	[TestClass]
	public class SharpPcapInformationSourceTests
	{
		[TestMethod]
		public void CheckSharpPcapIsWorking_ReturnAVersionNumber()
		{
			//Arrange
			//Act
			string version = SharpPcap.Version.VersionString;

			//Assert
			Assert.IsTrue(!string.IsNullOrEmpty(version));
		}

		[TestMethod]
		public void CheckDevicesAvailableToCapture_DevicesFound()
		{		
			//Arrange
			//Act
			CaptureDeviceList deviceList = CaptureDeviceList.Instance;

			//Assert
			Assert.IsTrue(deviceList.Count > 0);
		}


		[TestMethod]
		public void CheckDevicesCapture_FtpNetworkTrafficDataFound()
		{
			//Arrange
			var captureDevice = new TestCaptureDevice();
			bool ftpCaptureOccured = false;

			//Act
			SharpPcapInformationSource networkInformationSource = new SharpPcapInformationSource(captureDevice, 2000);
			networkInformationSource.NetworkAlert += delegate {
				ftpCaptureOccured = true;
			};
			networkInformationSource.StartListening();

			//Assert
			Assert.IsTrue(ftpCaptureOccured);

		}

		private void NetworkInformationSource_NetworkAlert1(object sender, System.EventArgs e)
		{
			
		}

		private void NetworkInformationSource_NetworkAlert(object sender, System.EventArgs e)
		{
			throw new System.NotImplementedException();
		}
	}
}
