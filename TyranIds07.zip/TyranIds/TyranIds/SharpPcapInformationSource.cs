using System;
using SharpPcap;

namespace TyranIds
{
	public class SharpPcapInformationSource : SimpleInformationSource
	{
		private ICaptureDevice captureDevice;

		public event EventHandler NetworkAlert;

		public SharpPcapInformationSource(TestCaptureDevice device, int i)
		{
			captureDevice = device;
			captureDevice.OnPacketArrival += CaptureDevice_OnPacketArrival;
		}

		private void CaptureDevice_OnPacketArrival(object sender, CaptureEventArgs e)
		{
			AddNetworkMessage(e.Packet.Data.ToString());
			NetworkAlert(this, new EventArgs());
		}


		public void StartListening()
		{
			captureDevice.StartCapture();
		}

	}
}