﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace TyranIds.Tests
{
	[TestClass]
	public class ReportTests
	{
		[TestMethod]
		public async Task TestSimpleReporter_ReportsSucessfully()
		{		
			//arrange
			IReportAgent reportAgent = NSubstitute.Substitute.For<IReportAgent>();
			var captureDevice = new TestCaptureDevice();
			SharpPcapInformationSource networkInformationSource = new SharpPcapInformationSource(captureDevice, 2000);
			SimpleRule simpleRule = new SimpleRule("FTP");
			Sensor sensor = new Sensor(networkInformationSource,simpleRule, reportAgent);

			//act
			sensor.Start();
			await TestPause();

			//assert
			reportAgent.ReceivedWithAnyArgs().ReportPacketCaptured(null, DateTime.Now, Guid.Empty);
		}

		private async Task TestPause()
		{
			await Task.Delay(20000);
		}
	}


}
