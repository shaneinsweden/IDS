using System;
using System.CodeDom;
using System.Text.RegularExpressions;
using PacketDotNet;
using SharpPcap;
using TyranIds.Interfaces;

namespace TyranIds
{
	public class SharpPcapInformationSource : SimpleInformationSource, IActiveInformationSource
	{
		private ICaptureDevice captureDevice;

		public event EventHandler NetworkAlert;

		private readonly Guid id;

		public SharpPcapInformationSource(TestCaptureDevice device, int i)
		{
			captureDevice = device;
			captureDevice.OnPacketArrival += CaptureDevice_OnPacketArrival;
			id = Guid.NewGuid();
		}

		private void CaptureDevice_OnPacketArrival(object sender, CaptureEventArgs e)
		{
			NetworkEventArgs netArgs = ExtractNetworkInformation(e.Packet);

			AddNetworkMessage(netArgs.PayloadText);

			if (NetworkAlert != null)
				NetworkAlert(this, netArgs);
		}

		private NetworkEventArgs ExtractNetworkInformation(RawCapture packet)
		{
			EthernetPacket ethernetPacket = PacketDotNet.Packet.ParsePacket(LinkLayers.Ethernet, packet.Data) as EthernetPacket;
			IpPacket ipPacket = ethernetPacket.Extract(typeof(IpPacket)) as IpPacket;
			TcpPacket tcpPacket = ethernetPacket.Extract(typeof(TcpPacket)) as TcpPacket;

			string rawMessageText = System.Text.Encoding.UTF8.GetString(ethernetPacket.Bytes);
			
			string cleanMessageText = Regex.Replace(rawMessageText,@"[^a-zA-Z0-9`!@#$%^&*()_+|\-=\\{}\[\]:"";'<>?,./]", "");

			return new NetworkEventArgs(ipPacket.DestinationAddress.ToString(), tcpPacket.DestinationPort.ToString(), ipPacket.SourceAddress.ToString(), tcpPacket.SourcePort.ToString(), cleanMessageText, DateTime.Now, id);
		}

		public void StartListening()
		{
			captureDevice.StartCapture();
		}

		public void StopListening()
		{
			captureDevice.StopCapture();
		}
	}


	public class NetworkEventArgs : EventArgs
	{
		public string  DestinationIpAddress { get; set; }
		public string SourceIpAddress { get; set; }
		public string DestinationPort { get; set; }
		public string SourcePort { get; set; }
		public string PayloadText { get; set; }
		public DateTime Captured { get; set; }
		public Guid DatasourceId { get; set; }

		public NetworkEventArgs(string destIpAddress, string destPort, string srcIpAddress, string srcPort, string payloadText, DateTime captured, Guid datasourceId)
		{
			DestinationIpAddress = destIpAddress;
			SourceIpAddress = srcIpAddress;
			DestinationPort = destPort;
			SourcePort = srcPort;
			PayloadText = payloadText;
			DatasourceId = datasourceId;
			Captured = captured;
		}
	}
}