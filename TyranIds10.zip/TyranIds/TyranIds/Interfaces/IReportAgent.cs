using System;
using PacketDotNet;

namespace TyranIds
{
	public interface IReportAgent
	{
		void ReportPacketCaptured(Packet packet, DateTime captureTime, Guid sensorId);
	}
}