﻿namespace TyranIds.Interfaces
{
	public interface IInformationSource
	{
		void AddNetworkMessage(string hello);
		int BufferCount { get;  }
		string GetNextMessage();
	}

	public interface IActiveInformationSource : IInformationSource
	{
		void StartListening();
		void StopListening();
	}

}